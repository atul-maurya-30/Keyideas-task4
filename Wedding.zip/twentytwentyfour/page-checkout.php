<?php
/**
 * Template Name: Checkout Page
 */
get_header();
$cart_items = $_SESSION['my_cart'] ?? [];
$cart_total = 0;

foreach ($cart_items as $item) {
    $cart_total += $item['price'] * $item['quantity'];
}

// Redirect if cart is empty
if (empty($cart_items)) {
    wp_redirect(home_url('/cart'));
    exit;
}
?>
<!-- ✅ Navigation Bar -->
<nav class="custom-navbar">
    <div class="nav-container">
        <div class="nav-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="https://keyideas-wedding.iceiy.com/wp-content/uploads/2025/10/logo.6b793.png" alt="Logo">
            </a>
        </div>
        <ul class="nav-links">
            <li><a href="https://keyideas-wedding.iceiy.com/shop/">Shop</a></li>
            <li><a href="https://keyideas-wedding.iceiy.com/cart/">Cart</a></li>
            <li><a href="https://keyideas-wedding.iceiy.com/checkout/">Checkout</a></li>
        </ul>
    </div>
</nav>
<div class="checkout-page">
    <div class="container">
        <h1>Checkout</h1>
        
        <form id="checkout-form" class="checkout-form">
            <div class="checkout-content">
                <div class="checkout-details">
                    <div class="checkout-section">
                        <h2>Contact Information</h2>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                        </div>
                    </div>

                    <div class="checkout-section">
                        <h2>Shipping Address</h2>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name">First Name *</label>
                                <input type="text" id="first_name" name="first_name" required>
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name *</label>
                                <input type="text" id="last_name" name="last_name" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="address">Address *</label>
                                <input type="text" id="address" name="address" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="city">City *</label>
                                <input type="text" id="city" name="city" required>
                            </div>
                            <div class="form-group">
                                <label for="state">State *</label>
                                <select id="state" name="state" required>
                                    <option value="">Select State</option>
                                    <option value="AL">Alabama</option>
                                    <option value="AK">Alaska</option>
                                    <option value="AZ">Arizona</option>
                                    <option value="AR">Arkansas</option>
                                    <option value="CA">California</option>
                                    <option value="CO">Colorado</option>
                                    <option value="CT">Connecticut</option>
                                    <option value="DE">Delaware</option>
                                    <option value="FL">Florida</option>
                                    <option value="GA">Georgia</option>
                                    <option value="HI">Hawaii</option>
                                    <option value="ID">Idaho</option>
                                    <option value="IL">Illinois</option>
                                    <option value="IN">Indiana</option>
                                    <option value="IA">Iowa</option>
                                    <option value="KS">Kansas</option>
                                    <option value="KY">Kentucky</option>
                                    <option value="LA">Louisiana</option>
                                    <option value="ME">Maine</option>
                                    <option value="MD">Maryland</option>
                                    <option value="MA">Massachusetts</option>
                                    <option value="MI">Michigan</option>
                                    <option value="MN">Minnesota</option>
                                    <option value="MS">Mississippi</option>
                                    <option value="MO">Missouri</option>
                                    <option value="MT">Montana</option>
                                    <option value="NE">Nebraska</option>
                                    <option value="NV">Nevada</option>
                                    <option value="NH">New Hampshire</option>
                                    <option value="NJ">New Jersey</option>
                                    <option value="NM">New Mexico</option>
                                    <option value="NY">New York</option>
                                    <option value="NC">North Carolina</option>
                                    <option value="ND">North Dakota</option>
                                    <option value="OH">Ohio</option>
                                    <option value="OK">Oklahoma</option>
                                    <option value="OR">Oregon</option>
                                    <option value="PA">Pennsylvania</option>
                                    <option value="RI">Rhode Island</option>
                                    <option value="SC">South Carolina</option>
                                    <option value="SD">South Dakota</option>
                                    <option value="TN">Tennessee</option>
                                    <option value="TX">Texas</option>
                                    <option value="UT">Utah</option>
                                    <option value="VT">Vermont</option>
                                    <option value="VA">Virginia</option>
                                    <option value="WA">Washington</option>
                                    <option value="WV">West Virginia</option>
                                    <option value="WI">Wisconsin</option>
                                    <option value="WY">Wyoming</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="zip_code">ZIP Code *</label>
                                <input type="text" id="zip_code" name="zip_code" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone Number *</label>
                                <input type="tel" id="phone" name="phone" required>
                            </div>
                        </div>
                    </div>

                    <div class="checkout-section">
                        <h2>Payment Method</h2>
                        <div class="payment-methods">
                            <div class="payment-method">
                                <input type="radio" id="credit_card" name="payment_method" value="credit_card" checked>
                                <label for="credit_card">Credit Card</label>
                            </div>
                            <div class="payment-method">
                                <input type="radio" id="paypal" name="payment_method" value="paypal">
                                <label for="paypal">PayPal</label>
                            </div>
                        </div>

                        <div class="credit-card-form">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="card_number">Card Number *</label>
                                    <input type="text" id="card_number" name="card_number" placeholder="1234 5678 9012 3456">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="card_name">Name on Card *</label>
                                    <input type="text" id="card_name" name="card_name">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="expiry_date">Expiry Date *</label>
                                    <input type="text" id="expiry_date" name="expiry_date" placeholder="MM/YY">
                                </div>
                                <div class="form-group">
                                    <label for="cvv">CVV *</label>
                                    <input type="text" id="cvv" name="cvv" placeholder="123">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="order-summary">
                    <div class="summary-card">
                        <h3>Order Summary</h3>
                        <div class="order-items">
                            <?php foreach ($cart_items as $item): ?>
                                <div class="order-item">
                                    <div class="item-image">
                                        <img src="<?php echo esc_url($item['image']); ?>" alt="<?php echo esc_attr($item['name']); ?>">
                                    </div>
                                    <div class="item-info">
                                        <h4><?php echo esc_html($item['name']); ?></h4>
                                        <p>Metal: <?php echo esc_html($item['metal']); ?></p>
                                        <p>Qty: <?php echo esc_html($item['quantity']); ?></p>
                                    </div>
                                    <div class="item-price">
                                        $<?php echo number_format($item['price'] * $item['quantity'], 2); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="summary-totals">
                            <div class="summary-row">
                                <span>Subtotal:</span>
                                <span>$<?php echo number_format($cart_total, 2); ?></span>
                            </div>
                            <div class="summary-row">
                                <span>Shipping:</span>
                                <span>Free</span>
                            </div>
                            <div class="summary-row">
                                <span>Tax:</span>
                                <span>$<?php echo number_format($cart_total * 0.08, 2); ?></span>
                            </div>
                            <div class="summary-row total">
                                <span>Total:</span>
                                <span>$<?php echo number_format($cart_total * 1.08, 2); ?></span>
                            </div>
                        </div>
                        
                        <button type="submit" class="place-order-btn">Place Order</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<div id="checkout-notification" style="display: none;"></div>

<?php get_footer(); ?>