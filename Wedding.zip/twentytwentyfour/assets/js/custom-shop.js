document.addEventListener('DOMContentLoaded', () => {

  /* -------------------------------
     DROPDOWN TOGGLE FUNCTIONALITY
  ------------------------------- */
  document.querySelectorAll('.dropbtn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.preventDefault();
      const parent = btn.parentElement;
      const isActive = parent.classList.toggle('active');
      btn.classList.toggle('active');
        
      // Close other dropdowns
      document.querySelectorAll('.dropdown').forEach(d => {
        if (d !== parent) {
          d.classList.remove('active');
          d.querySelector('.dropbtn')?.classList.remove('active');
        }
      });
      // Rotate arrow
      const arrow = btn.querySelector('.arrow-icon svg');
      if (arrow) {
        arrow.style.transform = isActive ? 'rotate(180deg)' : 'rotate(0deg)';
      }
    });
  });

  // Close dropdowns when clicking outside
  window.addEventListener('click', e => {
    if (!e.target.closest('.dropdown')) {
      document.querySelectorAll('.dropdown').forEach(d => {
        d.classList.remove('active');
        const btn = d.querySelector('.dropbtn');
        if (btn) {
          btn.classList.remove('active');
          const arrow = btn.querySelector('.arrow-icon svg');
          if (arrow) arrow.style.transform = 'rotate(0deg)';
        }
      });
    }
  });

  /* -------------------------------
     PRICE SLIDER FUNCTIONALITY
  ------------------------------- */
  const rangeInputs   = document.querySelectorAll(".range-input input");
  const range         = document.querySelector(".range-slider .range-selected");
  const minPriceLabel = document.getElementById("min-price-label");
  const maxPriceLabel = document.getElementById("max-price-label");
  const minHidden = document.getElementById('min-price-hidden');
  const maxHidden = document.getElementById('max-price-hidden');
  const minInput = document.getElementById("min-price");
  const maxInput = document.getElementById("max-price");
  const form = document.getElementById("filter-form");
  const minGap = 100;

  const formatCurrency = (num) => "$" + Number(num).toLocaleString("en-US");
  const parseCurrency  = (val) => parseInt(val.replace(/[^\d.-]/g, ""), 10) || 0;

  function syncHidden() {
    if (minHidden) minHidden.value = parseCurrency(minInput.value);
    if (maxHidden) maxHidden.value = parseCurrency(maxInput.value);
  }

  function updateSlider(event) {
    if (rangeInputs.length < 2) return;

    let minVal = parseInt(rangeInputs[0].value);
    let maxVal = parseInt(rangeInputs[1].value);

    if (maxVal - minVal < minGap) {
      if (event && event.target.classList.contains("min-range")) {
        rangeInputs[0].value = maxVal - minGap;
      } else {
        rangeInputs[1].value = minVal + minGap;
      }
      minVal = parseInt(rangeInputs[0].value);
      maxVal = parseInt(rangeInputs[1].value);
    }

    const max = parseInt(rangeInputs[0].max);
    if (range) {
      range.style.left  = (minVal / max) * 100 + "%";
      range.style.right = 100 - (maxVal / max) * 100 + "%";
    }

    if (minPriceLabel) minPriceLabel.textContent = formatCurrency(minVal);
    if (maxPriceLabel) maxPriceLabel.textContent = formatCurrency(maxVal);
    if (minInput) minInput.value = formatCurrency(minVal);
    if (maxInput) maxInput.value = formatCurrency(maxVal);
    syncHidden();
  }

  rangeInputs.forEach(input => {
    input.addEventListener("input", updateSlider);
    input.addEventListener("change", () => form?.submit());
  });

  [minInput, maxInput].forEach(input => {
    if (!input) return;
    input.addEventListener("focus", e => {
      e.target.value = parseCurrency(e.target.value);
    });

    input.addEventListener("blur", e => {
      const plain = parseCurrency(e.target.value);
      e.target.value = formatCurrency(plain);
      const isMin = input.id === "min-price";
      const slider = isMin ? rangeInputs[0] : rangeInputs[1];
      slider.value = plain;
      const otherVal = parseInt((isMin ? rangeInputs[1] : rangeInputs[0]).value);
      if (isMin && otherVal - plain < minGap) rangeInputs[1].value = plain + minGap;
      if (!isMin && plain - otherVal < minGap) rangeInputs[0].value = plain - minGap;
      updateSlider();
      syncHidden();
    });

    input.addEventListener("input", e => {
      e.target.value = e.target.value.replace(/[^\d]/g, "");
    });
  });

  if (form) {
    form.addEventListener("submit", () => {
      syncHidden();
    });
  }

  const realMin = rangeInputs[0]?.value;
  const realMax = rangeInputs[1]?.value;
  if (minInput && maxInput) {
    minInput.value = formatCurrency(realMin);
    maxInput.value = formatCurrency(realMax);
  }
  syncHidden();
  updateSlider();


  /* -------------------------------
     WISHLIST FUNCTIONALITY
  ------------------------------- */
  const wishlistBtns = document.querySelectorAll(".wishlist-btn");
  const wishlist = JSON.parse(localStorage.getItem("wishlist") || "[]");

  wishlistBtns.forEach(btn => {
    const card = btn.closest(".product-card");
    const product = JSON.parse(card.dataset.product);
    if (wishlist.find(item => item.name === product.name)) {
      btn.classList.add("active");
    }

    btn.addEventListener("click", e => {
      e.preventDefault();
      btn.classList.toggle("active");
      const active = btn.classList.contains("active");
      let stored = JSON.parse(localStorage.getItem("wishlist") || "[]");
      if (active) stored.push(product);
      else stored = stored.filter(p => p.name !== product.name);
      localStorage.setItem("wishlist", JSON.stringify(stored));
    });
  });
    // Scroll Buttons JS

    const scrollButtons = document.getElementById('scroll-buttons');
    if (!scrollButtons) {
        console.warn('Scroll buttons HTML not found!');
        return;
    }
    const scrollToTopBtn = document.getElementById('scroll-to-top');
    const scrollToBottomBtn = document.getElementById('scroll-to-bottom');

    const toggleVisibility = () => {
        if (window.scrollY > 300) {
            scrollButtons.classList.add('visible');
            scrollToTopBtn.style.display = 'flex';
            scrollToBottomBtn.style.display = 'none';
        } else {
            scrollButtons.classList.remove('visible');
            scrollToTopBtn.style.display = 'none';
            scrollToBottomBtn.style.display = 'flex';
        }
    };

    window.addEventListener('scroll', toggleVisibility);
    toggleVisibility(); // Initial check

    scrollToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    scrollToBottomBtn.addEventListener('click', () => {
        window.scrollTo({
            top: document.body.scrollHeight,
            behavior: 'smooth'
        });
    });
});

