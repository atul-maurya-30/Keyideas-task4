document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart and checkout functionality
    initCart();
    initCheckout();
});

function initCart() {
    // Quantity update handlers
    const quantityInputs = document.querySelectorAll('.quantity-input');
    quantityInputs.forEach(input => {
        input.addEventListener('change', function() {
            const itemId = this.dataset.itemId;
            const quantity = parseInt(this.value);
            
            if (quantity < 1) {
                this.value = 1;
                return;
            }
            
            updateCartQuantity(itemId, quantity);
        });
    });
    
    // Plus/Minus button handlers
    const plusButtons = document.querySelectorAll('.quantity-btn.plus');
    plusButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const itemId = this.dataset.itemId;
            const input = document.querySelector(`.quantity-input[data-item-id="${itemId}"]`);
            const currentValue = parseInt(input.value);
            input.value = currentValue + 1;
            updateCartQuantity(itemId, currentValue + 1);
        });
    });
    
    const minusButtons = document.querySelectorAll('.quantity-btn.minus');
    minusButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const itemId = this.dataset.itemId;
            const input = document.querySelector(`.quantity-input[data-item-id="${itemId}"]`);
            const currentValue = parseInt(input.value);
            
            if (currentValue > 1) {
                input.value = currentValue - 1;
                updateCartQuantity(itemId, currentValue - 1);
            }
        });
    });
    
    // Remove item handlers
    const removeButtons = document.querySelectorAll('.remove-btn');
    removeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const itemId = this.dataset.itemId;
            removeFromCart(itemId);
        });
    });
}

function initCheckout() {
    const wrappers = document.querySelectorAll('.checkout-section [data-wrapper]');
    const continueButtons = document.querySelectorAll('.continue-btn');
    const form = document.getElementById('checkout-form');
    const addressFinder = document.getElementById('address_finder');

    continueButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const currentWrapper = this.parentElement;
            const nextWrapperId = parseInt(this.getAttribute('data-next'));
            if (validateWrapper(currentWrapper)) {
                currentWrapper.style.display = 'none';
                document.querySelector(`.checkout-section [data-wrapper="${nextWrapperId}"]`).style.display = 'block';
            }
        });
    });

    addressFinder.addEventListener('input', function() {
        if (this.value.length > 5) {
            // Simulate address selection (replace with actual API call)
            const addressDetails = document.querySelectorAll('.address-details');
            addressDetails.forEach(el => el.style.display = 'block');
            // Example: Populate fields (to be replaced with API data)
            document.getElementById('address_line1').value = '123 Main St';
            document.getElementById('city').value = 'Gastonia';
            document.getElementById('state').value = 'NC';
            document.getElementById('zip_code').value = '28054';
        }
    });

    form.addEventListener('submit', function(e) {
        if (!validateForm()) {
            e.preventDefault();
            showNotification('Please fill all fields correctly.', 'error');
        }
    });
}

function updateCartQuantity(itemId, quantity) {
    showLoading(true);
    
    fetch(MY_CART_AJAX.ajax_url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            action: 'my_update_cart_quantity',
            item_id: itemId,
            quantity: quantity,
            nonce: MY_CART_AJAX.nonce
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Update the item total in the UI
            const itemElement = document.querySelector(`.cart-item[data-item-id="${itemId}"]`);
            if (itemElement) {
                const priceElement = itemElement.querySelector('.item-price');
                const totalElement = itemElement.querySelector('.item-total-value');
                
                const priceText = priceElement.textContent.trim();
                const cleanPrice = priceText.replace(/[$ ,]/g, '');
                const price = parseFloat(cleanPrice);
                
                if (isNaN(price)) {
                    throw new Error('Invalid price format');
                }
                
                const newTotal = price * quantity;
                totalElement.textContent = newTotal.toFixed(2);
            }
            
            recalculateCartTotals();
            showNotification('Quantity updated successfully', 'success');
        } else {
            showNotification('Error updating quantity: ' + (data.data || 'Unknown error'), 'error');
            location.reload();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error updating quantity. Please try again.', 'error');
        location.reload();
    })
    .finally(() => {
        showLoading(false);
    });
}

function removeFromCart(itemId) {
    if (!confirm('Are you sure you want to remove this item from your cart?')) {
        return;
    }
    
    showLoading(true);
    
    fetch(MY_CART_AJAX.ajax_url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            action: 'my_remove_from_cart',
            item_id: itemId,
            nonce: MY_CART_AJAX.nonce
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            const itemElement = document.querySelector(`.cart-item[data-item-id="${itemId}"]`);
            if (itemElement) {
                itemElement.style.animation = 'fadeOut 0.3s ease-out';
                setTimeout(() => {
                    itemElement.remove();
                    const cartItems = document.querySelector('.cart-items');
                    if (!cartItems.children.length) {
                        location.reload();
                    } else {
                        recalculateCartTotals();
                        updateCartCount(document.querySelectorAll('.cart-item').length);
                    }
                }, 300);
            }
            showNotification('Item removed from cart', 'success');
        } else {
            showNotification('Error removing item: ' + (data.data || 'Unknown error'), 'error');
            location.reload();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error removing item. Please try again.', 'error');
        location.reload();
    })
    .finally(() => {
        showLoading(false);
    });
}

function recalculateCartTotals() {
    let subtotal = 0;
    const totalElements = document.querySelectorAll('.item-total-value');
    
    totalElements.forEach(el => {
        const value = parseFloat(el.textContent.replace(/[$ ,]/g, ''));
        if (!isNaN(value)) {
            subtotal += value;
        }
    });
    
    const subtotalElement = document.getElementById('cart-subtotal');
    const totalElement = document.getElementById('cart-total');
    
    if (subtotalElement) {
        subtotalElement.textContent = '$' + subtotal.toFixed(2);
    }
    
    if (totalElement) {
        totalElement.textContent = '$' + subtotal.toFixed(2);
    }
}

function updateCartCount(count) {
    const cartCountElement = document.querySelector('.cart-count');
    if (cartCountElement) {
        if (count > 0) {
            cartCountElement.textContent = count;
            cartCountElement.style.display = 'inline-block';
        } else {
            cartCountElement.style.display = 'none';
        }
    }
}

function showNotification(message, type = 'info') {
    const existingNotifications = document.querySelectorAll('.custom-notification');
    existingNotifications.forEach(notification => notification.remove());
    
    const notification = document.createElement('div');
    notification.className = `custom-notification ${type}`;
    notification.textContent = message;
    
    let bgColor = '#2196F3';
    if (type === 'success') bgColor = '#4CAF50';
    if (type === 'error') bgColor = '#f44336';
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 4px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        background: ${bgColor};
        animation: slideIn 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideIn 0.3s ease-out reverse';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, 5000);
}

function showLoading(show) {
    if (show) {
        document.body.classList.add('loading');
    } else {
        document.body.classList.remove('loading');
    }
}

function validateWrapper(wrapper) {
    const inputs = wrapper.querySelectorAll('input[required], select[required]');
    let isValid = true;
    inputs.forEach(input => {
        if (!input.checkValidity()) isValid = false;
    });
    return isValid;
}

function validateForm() {
    const phone = document.getElementById('phone');
    const cardNumber = document.getElementById('card_number');
    const expiryDate = document.getElementById('expiry_date');
    const cvv = document.getElementById('cvv');

    if (!phone.checkValidity() || phone.value.length !== 10) {
        phone.setCustomValidity('Phone number must be 10 digits.');
        return false;
    } else {
        phone.setCustomValidity('');
    }
    if (!cardNumber.checkValidity() || cardNumber.value.length !== 16) {
        cardNumber.setCustomValidity('Card number must be 16 digits.');
        return false;
    } else {
        cardNumber.setCustomValidity('');
    }
    if (new Date(expiryDate.value) < new Date()) {
        expiryDate.setCustomValidity('Expiry date cannot be in the past.');
        return false;
    } else {
        expiryDate.setCustomValidity('');
    }
    if (!cvv.checkValidity() || (cvv.value.length !== 3 && cvv.value.length !== 4)) {
        cvv.setCustomValidity('CVV must be 3 or 4 digits.');
        return false;
    } else {
        cvv.setCustomValidity('');
    }
    return true;
}

// Add animations
if (!document.querySelector('#cart-animations')) {
    const style = document.createElement('style');
    style.id = 'cart-animations';
    style.textContent = `
        @keyframes fadeOut {
            from { opacity: 1; transform: translateY(0); }
            to { opacity: 0; transform: translateY(-10px); }
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(100%); }
            to { opacity: 1; transform: translateX(0); }
        }
    `;
    document.head.appendChild(style);
}