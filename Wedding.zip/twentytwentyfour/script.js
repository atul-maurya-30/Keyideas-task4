document.addEventListener("DOMContentLoaded", () => {
  const priceMin = document.getElementById("price-min");
  const priceMax = document.getElementById("price-max");
  const priceValue = document.getElementById("price-value");

  const applyBtn = document.getElementById("apply-filters");

  function updatePrice() {
    priceValue.textContent = `$${priceMin.value} - $${priceMax.value}`;
  }

  priceMin.addEventListener("input", updatePrice);
  priceMax.addEventListener("input", updatePrice);

  applyBtn.addEventListener("click", () => {
    const minPrice = parseInt(priceMin.value);
    const maxPrice = parseInt(priceMax.value);
    const weight = document.getElementById("weight-range").value;
    const diamond = document.getElementById("diamond-range").value;
    const cwt = document.getElementById("cwt-range").value;
    const plainMetal = document.getElementById("plain-metal").checked;
    const onSale = document.getElementById("on-sale").checked;

    document.querySelectorAll(".product-card").forEach(card => {
      const price = parseInt(card.dataset.price);
      const cardWeight = parseFloat(card.dataset.weight);
      const cardDiamond = parseInt(card.dataset.diamond);
      const cardCwt = parseFloat(card.dataset.cwt);
      const cardPlain = card.dataset.plain.includes("plain");
      const cardSale = card.dataset.sale.includes("yes");

      let visible = true;

      if (price < minPrice || price > maxPrice) visible = false;
      if (weight) {
        const [min, max] = weight.split("-").map(parseFloat);
        if (cardWeight < min || cardWeight > max) visible = false;
      }
      if (diamond) {
        const [min, max] = diamond.split("-").map(parseInt);
        if (cardDiamond < min || cardDiamond > max) visible = false;
      }
      if (cwt) {
        const [min, max] = cwt.split("-").map(parseFloat);
        if (cardCwt < min || cardCwt > max) visible = false;
      }
      if (plainMetal && !cardPlain) visible = false;
      if (onSale && !cardSale) visible = false;

      card.style.display = visible ? "block" : "none";
    });
  });
});
