<?php
/**
 * Template Name: Shop Page
 */
get_header();

// ✅ Load CSV Data
function load_csv_data() {
    $file = get_template_directory() . '/assets/csv/products.csv';
    if (!file_exists($file)) return [];

    $rows = array_map('str_getcsv', file($file));
    $header = array_map('trim', array_shift($rows));
    $data = [];
    foreach ($rows as $row) {
        $data[] = array_combine($header, $row);
    }
    return $data;
}

// ✅ Handle AJAX lazy loading request
if (isset($_GET['ajax_load']) && $_GET['ajax_load'] == 1) {
    $offset = intval($_GET['offset'] ?? 0);
    $limit  = intval($_GET['limit'] ?? 12);

    $products = load_csv_data();

    // Apply the same filtering logic
    $filters = [
        'prod_type' => [],
        'prod_subcategory' => [],
        'attr_14k_metal_available' => [],
        'prodmeta_metal_weight' => [],
        'prodmeta_side_diamonds_count' => [],
        'prodmeta_side_diamonds_ctw' => [],
    ];
    foreach ($products as $row) {
        foreach ($filters as $key => &$vals) {
            if (!empty($row[$key]) && !in_array(trim($row[$key]), $vals)) {
                $vals[] = trim($row[$key]);
            }
        }
    }
	// Sort filter options
    $filters['prodmeta_metal_weight'] = sort_numeric_unique($filters['prodmeta_metal_weight']);
    $filters['prodmeta_side_diamonds_count'] = sort_numeric_unique($filters['prodmeta_side_diamonds_count']);
    $filters['prodmeta_side_diamonds_ctw'] = sort_ctw($filters['prodmeta_side_diamonds_ctw']);
    // Other filters can remain as-is or add alphabetical sort if needed
    sort($filters['prod_type']);
    sort($filters['prod_subcategory']);
    sort($filters['attr_14k_metal_available']);
    $filtered = $products;
    $filter_keys = array_keys($filters);
    foreach ($filter_keys as $key) {
        if (isset($_GET[$key])) {
            $values = (array) $_GET[$key];
            if (!empty($values)) {
                $filtered = array_filter($filtered, function ($row) use ($key, $values) {
                    foreach ($values as $v) {
                        if (stripos($row[$key] ?? '', $v) !== false) return true;
                    }
                    return false;
                });
            }
        }
    }

    if (isset($_GET['prodmeta_section'])) {
        $v = $_GET['prodmeta_section'];
        $filtered = array_filter($filtered, function ($row) use ($v) {
            return ($row['prodmeta_section'] ?? '') === $v;
        });
    }

    $min_price_range = isset($_GET['min_price_range']) ? floatval($_GET['min_price_range']) : 0;
    $max_price_range = isset($_GET['max_price_range']) ? floatval($_GET['max_price_range']) : 9999999;
    $filtered = array_filter($filtered, function ($row) use ($min_price_range, $max_price_range) {
        $pr = floatval($row['attr_14k_regular']);
        return $pr >= $min_price_range && $pr <= $max_price_range;
    });

    if (isset($_GET['on_sale']) && $_GET['on_sale'] == '1') {
        $filtered = array_filter($filtered, function ($row) {
            $sku = intval($row['prod_sku']);
            return $sku % 5 === 0;
        });
    }

    if (isset($_GET['plain_metal']) && $_GET['plain_metal'] == '1') {
        $filtered = array_filter($filtered, function ($row) {
            return stripos($row['prod_subcategory'], 'Diamond') === false && stripos($row['prod_name'], 'Diamond') === false;
        });
    }

    if (isset($_GET['ship_within']) && $_GET['ship_within'] != '') {
        $max_ship = intval($_GET['ship_within']);
        $filtered = array_filter($filtered, function ($row) use ($max_ship) {
            $ship = intval($row['prodmeta_ship_days']);
            return $ship <= $max_ship;
        });
    }

    if (isset($_GET['sort']) && $_GET['sort'] != '') {
        $sort = $_GET['sort'];
        usort($filtered, function ($a, $b) use ($sort) {
            if ($sort == 'price_asc') {
                return floatval($a['attr_14k_regular']) <=> floatval($b['attr_14k_regular']);
            } elseif ($sort == 'price_desc') {
                return floatval($b['attr_14k_regular']) <=> floatval($a['attr_14k_regular']);
            } elseif ($sort == 'name_asc') {
                return strcmp($a['prod_name'], $b['prod_name']);
            }
            return 0;
        });
    }

    $all_products = array_slice(array_values($filtered), $offset, $limit);

    foreach ($all_products as $item) {
        $primary_img = $item['attr_whitegold_platinum_round_default_img']
            ?: 'https://via.placeholder.com/250?text=No+Image';
        $hover_img = $item['attr_rosegold_round_default_img']
            ?: $item['attr_yellowgold_round_default_img']
            ?: $primary_img;
        $price = floatval($item['attr_14k_regular']);
        $sku = intval($item['prod_sku']);
        $on_sale = ($sku % 5 === 0);
        $sale_price = $on_sale ? round($price * 0.7, 2) : $price;
        $discount = $on_sale ? round((1 - ($sale_price / $price)) * 100) : 0;
        $metals_str = trim($item['attr_14k_metal_available'] ?? '');
        $metals = $metals_str ? array_map('trim', explode(',', $metals_str)) : [];
        
        $name = $item['prod_name'] ?? '';
        $metal = $item['attr_14k_metal_available'] ?? '';
        $diamond = $item['prodmeta_side_diamonds_ctw'] ?? '';
        
        // Build readable title
        $display_name = $name;
        if ($metal || $diamond) {
            $parts = [];
            if ($metal) $parts[] = "In " . ucwords(trim($metal));
            if ($diamond) $parts[] = "(" . trim($diamond) . ")";
            $display_name .= " " . implode(' ', $parts);
        }

        echo '<div class="product-card" 
                 data-product="' . htmlspecialchars(json_encode([
                    'name' => $item['prod_name'] ?? '',
                    'price' => $item['attr_14k_regular'] ?? '',
                    'url' => $item['prod_live_url'] ?? '',
                    'image' => $primary_img
                 ]), ENT_QUOTES, 'UTF-8') . '">';
        echo '<div class="product-image">
                <a href="' . site_url('/product-detail/?id=' . urlencode($item['prod_name'])) . '">
                    <img src="' . esc_url($primary_img) . '" 
                         data-hover-src="' . esc_url($hover_img) . '" 
                         alt="' . esc_attr($item['prod_name']) . '" 
                         loading="lazy"
                         class="product-main-image">
                </a>
              </div>';
        echo '<div class="product-info">
                <div class="title-row">
                    <a href="' . site_url('/product-detail/?id=' . urlencode($item['prod_name'])) . '" class="product-name" title="' . esc_attr($display_name) . '">' . esc_html($display_name) . '</a>
                    <div class="wishlist-btn" title="Add to Wishlist"><i class="heart-icon"></i></div>
                </div>';
        echo '<div class="product-price">';
        if ($on_sale) {
            echo '<span class="old-price">$' . number_format($price, 0) . '</span>
                  <span class="sale-price">$' . number_format($sale_price, 0) . '</span>
                  <span class="discount">-' . $discount . '%</span>';
        } else {
            echo '<span class="price">$' . number_format($price, 0) . '</span>';
        }
        echo '</div><div class="metal-options">';
        foreach ($metals as $m) {
            $color = '#ccc';
            if (stripos($m, 'Yellow') !== false) $color = '#FFD700';
            elseif (stripos($m, 'White') !== false) $color = '#FFFFFF';
            elseif (stripos($m, 'Rose') !== false) $color = '#FFB6C1';
            echo '<div class="metal-dot" style="background-color:' . esc_attr($color) . ';" title="' . esc_attr($m) . '"></div>';
        }
        echo '</div></div></div>';
    }
    exit;
}
// ✅ Helper functions for sorting
function sort_numeric_unique($values) {
    $numeric = array_filter($values, 'is_numeric');
    $numeric = array_unique(array_map('intval', $numeric)); // Use intval for integers like diamond counts
    sort($numeric, SORT_NUMERIC);
    return array_map('strval', $numeric); // Keep as strings for consistency
}

function sort_weight($values) {
    $parsed = [];
    foreach ($values as $v) {
        $v = trim($v);
        // Extract numeric from weights like '5.5 Grams'
        preg_match('/([\d\.]+)\s*Grams/i', $v, $matches);
        $num_str = $matches[1] ?? '';
        $num = floatval($num_str);
        $parsed[$v] = $num;
    }
    uasort($parsed, function($a, $b) { return $a <=> $b; });
    return array_keys($parsed);
}

function sort_ctw($values) {
   
    $parsed = [];
    foreach ($values as $v) {
        $v = trim($v);
        // Extract numeric from CTW like '0.35ct.' or '0.35 ctw'
        preg_match('/([\d\.]+)\s*ct\.?/i', $v, $matches);
        $num_str = $matches[1] ?? '';
        $num = floatval($num_str);
        $parsed[$v] = $num;
    }
    uasort($parsed, function($a, $b) { return $a <=> $b; });
    return array_keys($parsed);
}
// ✅ Normal Page rendering continues
$products = load_csv_data();

// ✅ Collect Filters
$filters = [
    'prod_type' => [],
    'prod_subcategory' => [],
    'attr_14k_metal_available' => [],
    'prodmeta_metal_weight' => [],
    'prodmeta_side_diamonds_count' => [],
    'prodmeta_side_diamonds_ctw' => [],
];

foreach ($products as $row) {
    foreach ($filters as $key => &$vals) {
        if (!empty($row[$key]) && !in_array(trim($row[$key]), $vals)) {
            $vals[] = trim($row[$key]);
        }
    }
}
// Sort filter options
$filters['prodmeta_metal_weight'] = sort_weight($filters['prodmeta_metal_weight']);
$filters['prodmeta_side_diamonds_count'] = sort_numeric_unique($filters['prodmeta_side_diamonds_count']);
$filters['prodmeta_side_diamonds_ctw'] = sort_ctw($filters['prodmeta_side_diamonds_ctw']);
// Alphabetical for others if desired
sort($filters['prod_type']);
sort($filters['prod_subcategory']);
sort($filters['attr_14k_metal_available']);
// Compute min/max price
$all_prices = [];
foreach ($products as $p) {
    $pr = floatval($p['attr_14k_regular']);
    if ($pr > 0) $all_prices[] = $pr;
}
$min_price = $all_prices ? min($all_prices) : 0;
$max_price = $all_prices ? max($all_prices) : 10000;
$min_price_range = isset($_GET['min_price_range']) ? floatval($_GET['min_price_range']) : $min_price;
$max_price_range = isset($_GET['max_price_range']) ? floatval($_GET['max_price_range']) : $max_price;

// ✅ Filtering Logic (Auto Applied)
$filtered = $products;
$filter_keys = array_keys($filters);
foreach ($filter_keys as $key) {
    if (isset($_GET[$key])) {
        $values = (array) $_GET[$key];
        if (!empty($values)) {
            $filtered = array_filter($filtered, function ($row) use ($key, $values) {
                foreach ($values as $v) {
                    if (stripos($row[$key] ?? '', $v) !== false) return true;
                }
                return false;
            });
        }
    }
}

// For prodmeta_section (gender)
if (isset($_GET['prodmeta_section'])) {
    $v = $_GET['prodmeta_section'];
    $filtered = array_filter($filtered, function ($row) use ($v) {
        return ($row['prodmeta_section'] ?? '') === $v;
    });
}

// For price range
if ($min_price_range > $min_price || $max_price_range < $max_price) {
    $filtered = array_filter($filtered, function ($row) use ($min_price_range, $max_price_range) {
        $pr = floatval($row['attr_14k_regular']);
        return $pr >= $min_price_range && $pr <= $max_price_range;
    });
}

// For on_sale
if (isset($_GET['on_sale']) && $_GET['on_sale'] == '1') {
    $filtered = array_filter($filtered, function ($row) {
        $sku = intval($row['prod_sku']);
        return $sku % 5 === 0;
    });
}

// For plain_metal
if (isset($_GET['plain_metal']) && $_GET['plain_metal'] == '1') {
    $filtered = array_filter($filtered, function ($row) {
        return stripos($row['prod_subcategory'], 'Diamond') === false && stripos($row['prod_name'], 'Diamond') === false;
    });
}

// For ship_within
if (isset($_GET['ship_within']) && $_GET['ship_within'] != '') {
    $max_ship = intval($_GET['ship_within']);
    $filtered = array_filter($filtered, function ($row) use ($max_ship) {
        $ship = intval($row['prodmeta_ship_days']);
        return $ship <= $max_ship;
    });
}

// For sort
if (isset($_GET['sort']) && $_GET['sort'] != '') {
    $sort = $_GET['sort'];
    usort($filtered, function ($a, $b) use ($sort) {
        if ($sort == 'price_asc') {
            return floatval($a['attr_14k_regular']) <=> floatval($b['attr_14k_regular']);
        } elseif ($sort == 'price_desc') {
            return floatval($b['attr_14k_regular']) <=> floatval($a['attr_14k_regular']);
        } elseif ($sort == 'name_asc') {
            return strcmp($a['prod_name'], $b['prod_name']);
        }
        return 0;
    });
}

$total = count($filtered);

// ✅ Helper for Metal Colors and Short Names
function metal_info($metal) {
    $info = [
        'Yellow Gold' => ['color' => '#FFD700', 'short' => 'YG'],
        'White Gold' => ['color' => '#FFFFFF', 'short' => 'WG'],
        'Rose Gold' => ['color' => '#FFB6C1', 'short' => 'RG'],
        'WRG' => ['color' => '#e0dede', 'short' => 'WRG'],
        'WYG' => ['color' => '#f9d47f', 'short' => 'WYG'],
        'Tri Color' => ['color' => '#d1a375', 'short' => 'TC'],
        'Platinum' => ['color' => '#c0c0c0', 'short' => 'Pt'],
    ];
    return $info[$metal] ?? ['color' => '#ccc', 'short' => substr($metal, 0, 2)];
}
?>
<!-- ✅ Navigation Bar -->
<nav class="custom-navbar">
    <div class="nav-container">
        <div class="nav-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="https://keyideas-wedding.iceiy.com/wp-content/uploads/2025/10/logo.6b793.png" alt="Logo">
            </a>
        </div>
        <ul class="nav-links">
            <li><a href="https://keyideas-wedding.iceiy.com/shop/">Shop</a></li>
        </ul>
    </div>
</nav>

<div class="shop-page-wrap">
    <div class="shop-header">
        <h1>Shop Wedding Bands And Wedding Rings</h1>
        <p>
            Celebrate your relationship with the perfect wedding ring. Our men's and women's wedding bands feature the finest platinum, gold and contemporary metals. Shop artisan wedding rings with diamonds, gemstones and hand finished details. From modern wedding rings to classic designs, you're sure to find your fit in our wedding ring collection.
        </p>
        <div class="gender-buttons">
            <?php
            $current_section = $_GET['prodmeta_section'] ?? '';
            $base_params = $_GET;
            unset($base_params['prodmeta_section']);

            // For Women
            $params_w = $base_params;
            if ($current_section == 'Womens') {
                $women_url = '?' . http_build_query($params_w);
                $women_active = 'active';
            } else {
                $params_w['prodmeta_section'] = 'Womens';
                $women_url = '?' . http_build_query($params_w);
                $women_active = '';
            }

            // For Men
            $params_m = $base_params;
            if ($current_section == 'Mens') {
                $mens_url = '?' . http_build_query($params_m);
                $mens_active = 'active';
            } else {
                $params_m['prodmeta_section'] = 'Mens';
                $mens_url = '?' . http_build_query($params_m);
                $mens_active = '';
            }
            ?>
            <a href="<?php echo esc_url($women_url); ?>" class="btn <?php echo $women_active; ?>">Women</a>
            <a href="<?php echo esc_url($mens_url); ?>" class="btn <?php echo $mens_active; ?>">Men</a>
        </div>
    </div>

    <!-- ✅ Filter Section -->
    <form method="get" id="filter-form">
        <div class="dropdown-filters">
            <?php
            $filter_titles = [
                'prod_type' => 'Style',
                'prod_subcategory' => 'Subcategory',
                'prodmeta_side_diamonds_count' => 'Diamond Count',
                'prodmeta_side_diamonds_ctw' => 'CTW',
                'attr_14k_metal_available' => 'Metal',
                'prodmeta_metal_weight' => 'Weight',
            ];

            foreach ($filters as $key => $options): ?>
    <div class="dropdown <?php echo esc_attr($key); ?>-dropdown">
        <button class="dropbtn">
            <span class="filter-text"><?php echo esc_html($filter_titles[$key]); ?></span>
            <span class="arrow-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="8" height="4" fill="none">
                    <path fill="#151542" d="M4 4 0 0h8z"></path>
                </svg>
            </span>
        </button>

        <div class="dropdown-content">
            <h4><?php echo esc_html($filter_titles[$key]); ?></h4>
            <div class="checkbox-grid">
                <?php foreach ($options as $opt): ?>
                    <label>
                        <input type="checkbox" name="<?php echo esc_attr($key); ?>[]" value="<?php echo esc_attr($opt); ?>"
                            <?php if (isset($_GET[$key]) && in_array($opt, (array) $_GET[$key])) echo 'checked'; ?>
                            onchange="document.getElementById('filter-form').submit()">
                        <?php echo esc_html($opt); ?>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endforeach;?>

     <!-- ✅ Price Dropdown with Input + Dual Range Slider -->
<div class="dropdown price-dropdown">
  <button class="dropbtn">
    
    <span class="filter-text">Price</span>
    <span class="arrow-icon">
      <svg xmlns="http://www.w3.org/2000/svg" width="8" height="4" fill="none">
        <path fill="#151542" d="M4 4 0 0h8z"></path>
      </svg>
    </span>
  </button>

  <div class="dropdown-content">
    <h4>Price Range</h4>

    <!-- Visible formatted inputs (what the user sees) -->
    <div class="price-inputs">
      <div class="input-group">
        <label for="min-price">Min Price</label>
        <div class="price-display">
          <input type="text"
                 id="min-price"
                 class="price-format"
                 value="<?php echo esc_attr( '$' . number_format( $min_price_range, 0, '.', ',' ) ); ?>"
                 autocomplete="off">
          <span class="formatted-price" data-for="min-price"></span>
        </div>
      </div>

      <div class="input-group max1">
        <label for="max-price">Max Price</label>
        <div class="price-display">
          <input type="text"
                 id="max-price"
                 class="price-format"
                 value="<?php echo esc_attr( '$' . number_format( $max_price_range, 0, '.', ',' ) ); ?>"
                 autocomplete="off">
          <span class="formatted-price" data-for="max-price"></span>
        </div>
      </div>
    </div>

    <!-- Hidden fields that travel with the form (plain numbers) -->
    <input type="hidden" name="min_price_range" id="min-price-hidden"
           value="<?php echo esc_attr( $min_price_range ); ?>">
    <input type="hidden" name="max_price_range" id="max-price-hidden"
           value="<?php echo esc_attr( $max_price_range ); ?>">
  
    <!-- Slider itself (still uses raw numbers) -->
    <div class="price-filter">
      <div class="range-slider">
        <div class="range-selected"></div>
      </div>

      <div class="range-input">
        <input type="range" class="min-range"
               min="<?php echo floor($min_price); ?>"
               max="<?php echo ceil($max_price); ?>"
               value="<?php echo $min_price_range; ?>" step="50">
        <input type="range" class="max-range"
               min="<?php echo floor($min_price); ?>"
               max="<?php echo ceil($max_price); ?>"
               value="<?php echo $max_price_range; ?>" step="50">
      </div>
    </div>
  </div>
</div>

            <div class="checkboxing">
                <label>
                    <input type="checkbox" name="on_sale" value="1"
                        <?php if (isset($_GET['on_sale']) && $_GET['on_sale'] == '1') echo 'checked'; ?>
                        onchange="document.getElementById('filter-form').submit()">
                    On Sale
                </label>
            </div>
            <div class="checkboxing">
                <label>
                    <input type="checkbox" name="plain_metal" value="1"
                        <?php if (isset($_GET['plain_metal']) && $_GET['plain_metal'] == '1') echo 'checked'; ?>
                        onchange="document.getElementById('filter-form').submit()">
                    Plain Metal
                </label>
            </div>
        </div>
    </form>

        <!-- Applied Filters -->
<div class="applied-filters">
<?php
$has_filters = false;
$special_keys = ['min_price_range', 'max_price_range', 'on_sale', 'plain_metal', 'ship_within', 'prodmeta_section'];
$label_map = $filter_titles;
$label_map['on_sale'] = 'Price';
$label_map['plain_metal'] = 'Features';
$label_map['ship_within'] = 'Ship Within';
$label_map['prodmeta_section'] = 'Section';
$label_map['min_price_range'] = 'Price';
$label_map['max_price_range'] = 'Price';

// -------------------------------------------------------------
// ✅ Handle combined Price Range (min + max shown as one chip)
// -------------------------------------------------------------
$min_price = isset($_GET['min_price_range']) ? (int)$_GET['min_price_range'] : null;
$max_price = isset($_GET['max_price_range']) ? (int)$_GET['max_price_range'] : null;

if ($min_price !== null && $max_price !== null) {
    $has_filters = true;
    $params = $_GET;
    unset($params['min_price_range'], $params['max_price_range']);
    $remove_url = '?' . http_build_query($params);

    echo '<span class="applied-chip">$' . number_format($min_price, 0) . ' – $' . number_format($max_price, 0) .
         ' <a class="close" href="' . esc_url($remove_url) . '" aria-label="Remove filter">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" stroke="rgb(69,70,83)" stroke-width="1.5" stroke-linecap="round">
                <line x1="1" y1="1" x2="11" y2="11" />
                <line x1="11" y1="1" x2="1" y2="11" />
            </svg>
         </a></span>';
}

// -------------------------------------------------------------
// ✅ Handle Gender Filter (prodmeta_section)
// -------------------------------------------------------------
if (isset($_GET['prodmeta_section'])) {
    $v = $_GET['prodmeta_section'];
    $has_filters = true;
    
    // Format readable value
    $display_value = ($v == 'Womens') ? 'Women' : (($v == 'Mens') ? 'Men' : $v);
    
    // Create remove link
    $params = $_GET;
    unset($params['prodmeta_section']);
    $remove_url = '?' . http_build_query($params);

    echo '<span class="applied-chip">' . esc_html($display_value) . 
         ' <a class="close" href="' . esc_url($remove_url) . '" aria-label="Remove filter">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" stroke="rgb(69,70,83)" stroke-width="1.5" stroke-linecap="round">
                <line x1="1" y1="1" x2="11" y2="11" />
                <line x1="11" y1="1" x2="1" y2="11" />
            </svg>
         </a></span>';
}

// -------------------------------------------------------------
// ✅ Handle Checkbox Filters (on_sale, plain_metal)
// -------------------------------------------------------------
$checkbox_filters = ['on_sale', 'plain_metal'];
foreach ($checkbox_filters as $key) {
    if (isset($_GET[$key]) && $_GET[$key] == '1') {
        $has_filters = true;
        
        // Format readable value
        $display_value = ($key == 'on_sale') ? 'On Sale' : 'Plain Metal';
        
        // Create remove link
        $params = $_GET;
        unset($params[$key]);
        $remove_url = '?' . http_build_query($params);

        echo '<span class="applied-chip">' . esc_html($display_value) . 
             ' <a class="close" href="' . esc_url($remove_url) . '" aria-label="Remove filter">
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" stroke="rgb(69,70,83)" stroke-width="1.5" stroke-linecap="round">
                    <line x1="1" y1="1" x2="11" y2="11" />
                    <line x1="11" y1="1" x2="1" y2="11" />
                </svg>
             </a></span>';
    }
}

// -------------------------------------------------------------
// ✅ Handle Shipping Filter
// -------------------------------------------------------------
if (isset($_GET['ship_within']) && $_GET['ship_within'] != '') {
    $v = $_GET['ship_within'];
    $has_filters = true;
    
    // Format readable value
    $display_value = $v . ' days';
    
    // Create remove link
    $params = $_GET;
    unset($params['ship_within']);
    $remove_url = '?' . http_build_query($params);

    echo '<span class="applied-chip">' . esc_html($display_value) . 
         ' <a class="close" href="' . esc_url($remove_url) . '" aria-label="Remove filter">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" stroke="rgb(69,70,83)" stroke-width="1.5" stroke-linecap="round">
                <line x1="1" y1="1" x2="11" y2="11" />
                <line x1="11" y1="1" x2="1" y2="11" />
            </svg>
         </a></span>';
}

// -------------------------------------------------------------
// ✅ Handle all other filters normally (only show value text)
// -------------------------------------------------------------
foreach ($filter_keys as $key) {
    if (isset($_GET[$key])) {
        $values = (array) $_GET[$key];
        if (!empty($values)) {
            $has_filters = true;
            foreach ($values as $v) {
                if ($v === '') continue;

                // Create remove link
                $params = $_GET;
                $vals = (array) $params[$key];
                $idx = array_search($v, $vals);
                if ($idx !== false) unset($vals[$idx]);
                if (empty($vals)) unset($params[$key]);
                else $params[$key] = $vals;
                $remove_url = '?' . http_build_query($params);

                echo '<span class="applied-chip">' . esc_html($v) . 
                     ' <a class="close" href="' . esc_url($remove_url) . '" aria-label="Remove filter">
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" stroke="rgb(69,70,83)" stroke-width="1.5" stroke-linecap="round">
                            <line x1="1" y1="1" x2="11" y2="11" />
                            <line x1="11" y1="1" x2="1" y2="11" />
                        </svg>
                     </a></span>';
            }
        }
    }
}

// -------------------------------------------------------------
// ✅ Show Reset Filters link only if filters exist
// -------------------------------------------------------------
if ($has_filters) {
    echo '<span class="reset-filters"><a href="?">Reset Filters</a></span>';
}
?>
</div>

   <!-- ✅ Results Bar -->
<?php
// Generate next 6 days including today for shipping dropdown
$today = new DateTime();
$shipping_dates = [];
for ($i = 0; $i < 6; $i++) {
    $date = clone $today;
    $date->modify("+$i day");
    $shipping_dates[] = $date;
}

// Determine selected sort and shipping
$current_sort = $_GET['sort'] ?? 'best_sellers';
$current_ship = $_GET['ship_within'] ?? '';
?>
<div class="results-bar">
    <div class="rs-total"><?php echo $total; ?> Results</div>

    <div class="rs-options">
        <!-- Sort By -->
        <div class="rs-dropdown">
            <div class="rs-label-top">Sort By</div>
            <button type="button" class="rs-btn">
                <span class="rs-value">
                    <?php
                        if ($current_sort === 'price_asc') echo 'Low to High';
                        elseif ($current_sort === 'price_desc') echo 'High to Low';
                        elseif ($current_sort === 'new_arrivals') echo 'New Arrivals';
                        elseif ($current_sort === 'fastest_shipping') echo 'Fastest Shipping';
                        else echo 'Best Sellers';
                    ?>
                </span>
                <span class="rs-arrow">▾</span>
            </button>

            <div class="rs-menu">
                <div class="rs-item <?php echo $current_sort==='best_sellers'?'active':''; ?>" onclick="updateSort('best_sellers')">Best Sellers</div>
                <div class="rs-text"> Price </div>
                <div class="rs-item <?php echo $current_sort==='price_asc'?'active':''; ?>" onclick="updateSort('price_asc')">Low to High</div>
                <div class="rs-item <?php echo $current_sort==='price_desc'?'active':''; ?>" onclick="updateSort('price_desc')">High to Low</div>
                <div class="rs-text"> Date </div>
                <div class="rs-item <?php echo $current_sort==='fastest_shipping'?'active':''; ?>" onclick="updateSort('fastest_shipping')">Fastest Shipping</div>
                <div class="rs-item <?php echo $current_sort==='new_arrivals'?'active':''; ?>" onclick="updateSort('new_arrivals')">New Arrivals</div>
            </div>
        </div>

        <!-- Shipping Date -->
        <div class="rs-dropdown">
            <div class="rs-label-top">Shipping Date by</div>
            <button type="button" class="rs-btn">
                <span class="rs-value">
                    <?php
                        if ($current_ship === '') echo 'Any Date';
                        else {
                            $sel_date = new DateTime();
                            $sel_date->modify("+{$current_ship} day");
                            echo $sel_date->format('l, M j');
                        }
                    ?>
                </span>
                <span class="rs-arrow">▾</span>
            </button>

            <div class="rs-menu">
                <div class="rs-item <?php echo $current_ship===''?'active':''; ?>" onclick="updateShip('')">Any Date</div>
                <?php foreach ($shipping_dates as $i => $d): ?>
                    <div class="rs-item <?php echo $current_ship==$i?'active':''; ?>" onclick="updateShip('<?php echo $i; ?>')">
                        <?php echo $d->format('l, M j'); ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
  

<script>
function updateSort(value) {
    const url = new URL(window.location.href);
    url.searchParams.set('sort', value);
    document.location = url.toString();
}

function updateShip(value) {
    const url = new URL(window.location.href);
    url.searchParams.set('ship_within', value);
    document.location = url.toString();
}

// Dropdown toggle
document.querySelectorAll('.rs-btn').forEach(btn => {
    btn.addEventListener('click', e => {
        e.stopPropagation();
        document.querySelectorAll('.rs-dropdown').forEach(d => d.classList.remove('open'));
        btn.parentElement.classList.toggle('open');
    });
});
document.addEventListener('click', () => {
    document.querySelectorAll('.rs-dropdown').forEach(d => d.classList.remove('open'));
});
</script>

    <!--Products-grid-->
<?php
$all_products = $filtered ?: [];
$total = count($all_products);
$limit = 12; // number of products to show per load
$initial_products = array_slice($all_products, 0, $limit);
?>

<div class="product-grid" id="product-grid"
     data-total="<?php echo $total; ?>"
     data-limit="<?php echo $limit; ?>">

    <?php foreach ($initial_products as $item): ?>
        <?php
            $primary_img = $item['attr_whitegold_platinum_round_default_img']
                ?: 'https://via.placeholder.com/250?text=No+Image';
            $hover_img = $item['attr_rosegold_round_default_img']
                ?: $item['attr_yellowgold_round_default_img']
                ?: $primary_img; // Fallback to primary if no hover image
            $price = floatval($item['attr_14k_regular']);
            $sku = intval($item['prod_sku']);
            $on_sale = ($sku % 5 === 0);
            $sale_price = $on_sale ? round($price * 0.7, 2) : $price;
            $discount = $on_sale ? round((1 - ($sale_price / $price)) * 100) : 0;
            $metals_str = trim($item['attr_14k_metal_available'] ?? '');
            $metals = $metals_str ? array_map('trim', explode(',', $metals_str)) : [];
            
            $name = $item['prod_name'] ?? '';
            $metal = $item['attr_14k_metal_available'] ?? '';
            $diamond = $item['prodmeta_side_diamonds_ctw'] ?? '';
            
            // Build readable title
            $display_name = $name;
            if ($metal || $diamond) {
                $parts = [];
                if ($metal) $parts[] = "In " . ucwords(trim($metal));
                if ($diamond) $parts[] = "(" . trim($diamond) . ")";
                $display_name .= " " . implode(' ', $parts);
            }
        ?>
        <div class="product-card"
             data-product="<?php echo htmlspecialchars(json_encode([
                'name'  => $item['prod_name'] ?? '',
                'price' => $item['attr_14k_regular'] ?? '',
                'url'   => $item['prod_live_url'] ?? '',
                'image' => $primary_img
             ]), ENT_QUOTES, 'UTF-8'); ?>">
            <div class="product-image">
                <a href="<?php echo site_url('/product-detail/?id=' . urlencode($item['prod_name'])); ?>">
                    <img src="<?php echo esc_url($primary_img); ?>" 
                         data-hover-src="<?php echo esc_url($hover_img); ?>" 
                         alt="<?php echo esc_attr($item['prod_name']); ?>" 
                         loading="lazy" 
                         class="product-main-image">
                </a>
            </div>
            <div class="product-info">
                <div class="title-row">
                    <a href="<?php echo site_url('/product-detail/?id=' . urlencode($name)); ?>"
                       class="product-name" title="<?php echo esc_attr($display_name); ?>">
                       <?php echo esc_html($display_name); ?>
                    </a>
                    <div class="wishlist-btn" title="Add to Wishlist"><i class="heart-icon"></i></div>
                </div>
                <div class="product-price">
                    <?php if ($on_sale): ?>
                        <span class="old-price">$<?php echo number_format($price, 0); ?></span>
                        <span class="sale-price">$<?php echo number_format($sale_price, 0); ?></span>
                        <span class="discount">-<?php echo $discount; ?>%</span>
                    <?php else: ?>
                        <span class="price">$<?php echo number_format($price, 0); ?></span>
                    <?php endif; ?>
                </div>
                <div class="metal-options">
                    <?php foreach ($metals as $m): $info = metal_info($m); ?>
                        <div class="metal-dot" style="background-color: <?php echo esc_attr($info['color']); ?>;"
                             title="<?php echo esc_attr($m); ?>"></div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div id="loader" style="text-align:center; margin:20px; display:none;">
    <p>Loading more products...</p>
</div>

<script>
// ✅ Global function to initialize image hover effects
function initImageHoverEffects() {
    const productImages = document.querySelectorAll('.product-main-image');
    
    productImages.forEach(img => {
        // Skip if already initialized
        if (img.hasAttribute('data-hover-initialized')) {
            return;
        }
        
        const hoverSrc = img.getAttribute('data-hover-src');
        const originalSrc = img.getAttribute('src');
        
        // Only add hover effect if hover image is different from original
        if (hoverSrc && hoverSrc !== originalSrc) {
            img.addEventListener('mouseenter', function() {
                this.style.opacity = '0';
                setTimeout(() => {
                    this.src = hoverSrc;
                    this.style.opacity = '1';
                }, 150);
            });

            img.addEventListener('mouseleave', function() {
                this.style.opacity = '0';
                setTimeout(() => {
                    this.src = originalSrc;
                    this.style.opacity = '1';
                }, 150);
            });

            // Mark as initialized
            img.setAttribute('data-hover-initialized', 'true');
            
            // Preload hover image
            const preloadImage = new Image();
            preloadImage.src = hoverSrc;
        }
    });
}

document.addEventListener("DOMContentLoaded", function() {
    let offset = 12;
    const limit = parseInt(document.getElementById("product-grid").dataset.limit);
    const total = parseInt(document.getElementById("product-grid").dataset.total);
    const grid = document.getElementById("product-grid");
    const loader = document.getElementById("loader");
    let loading = false;

    // Initialize hover effects for initial products
    initImageHoverEffects();

    const loadMore = async () => {
        if (loading || offset >= total) return;
        loading = true;
        loader.style.display = "block";

        const params = new URLSearchParams(window.location.search);
        params.set('ajax_load', 1);
        params.set('offset', offset);
        params.set('limit', limit);

        try {
            const res = await fetch(`?${params.toString()}`);
            const html = await res.text();
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = html;
            const newCards = tempDiv.querySelectorAll('.product-card');
            newCards.forEach(card => grid.appendChild(card));
            
            // ✅ Initialize hover effects for newly loaded products
            initImageHoverEffects();
            
            offset += limit;
        } catch (err) {
            console.error("Load more failed:", err);
        } finally {
            loader.style.display = "none";
            loading = false;
        }
    };

    window.addEventListener("scroll", () => {
        if ((window.innerHeight + window.scrollY) >= (document.body.offsetHeight - 300)) {
            loadMore();
        }
    });
});
</script>
    <!-- Scroll Buttons: Back to Top & Scroll to Bottom -->
<div id="scroll-buttons">
    <button id="scroll-to-top" title="Back to Top" aria-label="Scroll to top">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 19V5M5 12l7-7 7 7"/>
        </svg>
    </button>
    <button id="scroll-to-bottom" title="Scroll to Bottom" aria-label="Scroll to bottom">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 5v14M19 12l-7 7-7-7"/>
        </svg>
    </button>
</div>
<?php get_footer(); ?>