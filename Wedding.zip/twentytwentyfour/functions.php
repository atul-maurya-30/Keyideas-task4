<?php
/**
 * Theme Functions File
 * Handles product custom post type, CSV import, AJAX filters, lazy loading, cart, and checkout.
 */

/* ------------------------------
   A0: Theme Setup
------------------------------ */
function my_theme_setup() {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
}
add_action('after_setup_theme', 'my_theme_setup');


/* ------------------------------
   A1: Register Custom Post Type - Product
------------------------------ */
function my_register_product_cpt() {
    $labels = [
        'name' => 'Products',
        'singular_name' => 'Product',
        'menu_name' => 'Products',
        'name_admin_bar' => 'Product',
    ];

    $args = [
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'rewrite' => ['slug' => 'products'],
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
        'menu_icon' => 'dashicons-cart',
    ];

    register_post_type('product', $args);
}
add_action('init', 'my_register_product_cpt');


/* ------------------------------
   A2: Helper — Get DISTINCT Meta Values
------------------------------ */
function my_get_unique_meta_values($meta_key) {
    global $wpdb;
    $meta_key = sanitize_key($meta_key);
    if (empty($meta_key)) return [];

    $rows = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != ''",
        $meta_key
    ));

    $vals = [];
    foreach ($rows as $r) {
        $parts = array_map('trim', explode(',', $r));
        foreach ($parts as $p) {
            if ($p !== '') $vals[$p] = $p;
        }
    }
    $vals = array_values($vals);
    sort($vals, SORT_NATURAL | SORT_FLAG_CASE);
    return $vals;
}


/* ------------------------------
   A3: AJAX — Product Filters
------------------------------ */
add_action('wp_ajax_my_filter_products', 'my_ajax_filter_products');
add_action('wp_ajax_nopriv_my_filter_products', 'my_ajax_filter_products');

function my_build_like_meta_or($meta_key, $values) {
    $sub = ['relation' => 'OR'];
    foreach ($values as $v) {
        $sub[] = ['key' => $meta_key, 'value' => $v, 'compare' => 'LIKE'];
    }
    return $sub;
}

function my_ajax_filter_products() {
    check_ajax_referer('my_shop_nonce', 'nonce');
    $params = $_POST;
    $meta_query = ['relation' => 'AND'];

    $map = [
        'style' => 'style',
        'ring_size' => 'ring_size',
        'diamond_type' => 'diamond_type',
        'gemstones' => 'gemstones',
        'metal' => 'metal',
        'width' => 'width',
        'plain_metal' => 'plain_metal',
        'on_sale' => 'on_sale',
        'engravable' => 'engravable',
        'section' => 'prodmeta_section'
    ];

    foreach (['style','ring_size','diamond_type','gemstones','metal','width'] as $k) {
        if (!empty($params[$k])) {
            $vals = is_array($params[$k]) ? $params[$k] : explode(',', $params[$k]);
            $vals = array_map('sanitize_text_field', $vals);
            $meta_query[] = count($vals) === 1
                ? ['key' => $map[$k], 'value' => $vals[0], 'compare' => 'LIKE']
                : my_build_like_meta_or($map[$k], $vals);
        }
    }

    foreach (['plain_metal','on_sale','engravable'] as $b) {
        if (isset($params[$b]) && $params[$b] === '1') {
            $meta_query[] = ['key' => $b, 'value' => '1', 'compare' => '='];
        }
    }

    if (!empty($params['section'])) {
        $meta_query[] = ['key' => 'prodmeta_section', 'value' => sanitize_text_field($params['section']), 'compare' => '='];
    }

    if (!empty($params['price'])) {
        $p = sanitize_text_field($params['price']);
        if ($p === 'low') $meta_query[] = ['key' => 'price', 'value' => 500, 'type' => 'NUMERIC', 'compare' => '<'];
        elseif ($p === 'mid') $meta_query[] = ['key' => 'price', 'value' => [500,1000], 'type' => 'NUMERIC', 'compare' => 'BETWEEN'];
        elseif ($p === 'high') $meta_query[] = ['key' => 'price', 'value' => 1000, 'type' => 'NUMERIC', 'compare' => '>'];
    }

    if (isset($params['ship_offset']) && $params['ship_offset'] !== '' && is_numeric($params['ship_offset'])) {
        $meta_query[] = ['key' => 'prodmeta_ship_days', 'value' => intval($params['ship_offset']), 'type' => 'NUMERIC', 'compare' => '<='];
    }

    $args = [
        'post_type' => 'product',
        'posts_per_page' => 12,
        'meta_query' => $meta_query
    ];

    // Sorting
    $sort = isset($params['sort']) ? sanitize_text_field($params['sort']) : '';
    if ($sort === 'price_asc') {
        $args['meta_key'] = 'price';
        $args['orderby'] = 'meta_value_num';
        $args['order'] = 'ASC';
    } elseif ($sort === 'price_desc') {
        $args['meta_key'] = 'price';
        $args['orderby'] = 'meta_value_num';
        $args['order'] = 'DESC';
    } elseif ($sort === 'fastest_shipping') {
        $args['meta_key'] = 'prodmeta_ship_days';
        $args['orderby'] = 'meta_value_num';
        $args['order'] = 'ASC';
    } elseif ($sort === 'new_arrivals') {
        $args['orderby'] = 'date';
        $args['order'] = 'DESC';
    }

    $q = new WP_Query($args);
    ob_start();

    if ($q->have_posts()) :
        echo '<div class="product-grid-inner">';
        while ($q->have_posts()) : $q->the_post();
            $pid = get_the_ID();
            $price = get_post_meta($pid,'price',true);
            $img = has_post_thumbnail($pid) ? get_the_post_thumbnail_url($pid,'medium') : '';
            ?>
            <div class="product-card"
     data-product="<?php echo htmlspecialchars(json_encode([
        'name'  => get_the_title(),
        'price' => $price,
        'url'   => get_permalink(),
        'image' => $img
     ]), ENT_QUOTES, 'UTF-8'); ?>">


                <a href="<?php the_permalink(); ?>">
                    <?php if ($img): ?>
                        <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                    <?php endif; ?>
                    <h3><?php the_title(); ?></h3>
                    <p class="price">$<?php echo esc_html($price ?: '—'); ?></p>
                </a>
            </div>
            <?php
        endwhile;
        echo '</div>';
    else :
        echo '<p class="no-products">No products found.</p>';
    endif;

    wp_reset_postdata();
    $html = ob_get_clean();
    wp_send_json_success(['count' => $q->found_posts, 'html' => $html]);
}


/* ------------------------------
   A4: AJAX — Lazy Load Products (Independent)
------------------------------ */
add_action('wp_ajax_load_more_products', 'my_load_more_products');
add_action('wp_ajax_nopriv_load_more_products', 'my_load_more_products');

function my_load_more_products() {
    $paged = isset($_POST['page']) ? intval($_POST['page']) : 1;

    $args = [
        'post_type' => 'product',
        'posts_per_page' => 12,
        'paged' => $paged,
        'orderby' => 'date',
        'order' => 'DESC'
    ];

    $query = new WP_Query($args);

    ob_start();
    if ($query->have_posts()) :
        while ($query->have_posts()) : $query->the_post();
            $pid = get_the_ID();
            $price = get_post_meta($pid, 'price', true);
            $img = has_post_thumbnail($pid) ? get_the_post_thumbnail_url($pid, 'medium') : '';
            ?>
            <div class="product-card" data-id="<?php echo esc_attr($pid); ?>">
                <a href="<?php the_permalink(); ?>">
                    <?php if ($img): ?>
                        <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                    <?php endif; ?>
                    <h3><?php the_title(); ?></h3>
                    <p class="price">$<?php echo esc_html($price ?: '—'); ?></p>
                </a>
            </div>
            <?php
        endwhile;
    endif;
    wp_reset_postdata();

    $html = ob_get_clean();
    wp_send_json_success(['html' => $html]);
}


/* ------------------------------
   A5: Cart System Functions (IMPROVED VERSION)
------------------------------ */
function my_init_cart() {
    if (!isset($_SESSION)) {
        session_start();
    }
    if (!isset($_SESSION['my_cart'])) {
        $_SESSION['my_cart'] = [];
    }
}
add_action('init', 'my_init_cart');

// Add to cart AJAX handler
add_action('wp_ajax_my_add_to_cart', 'my_add_to_cart');
add_action('wp_ajax_nopriv_my_add_to_cart', 'my_add_to_cart');

function my_add_to_cart() {
    my_init_cart();
    
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'my_shop_nonce')) {
        wp_send_json_error('Security check failed');
    }
    
    // Get product data
    $product_data = json_decode(stripslashes($_POST['product_data']), true);
    
    if (!$product_data) {
        wp_send_json_error('No product data');
    }

    // Generate unique item ID based on name and metal
    $item_id = md5($product_data['name'] . $product_data['metal']);
    
    // Check if item already in cart
    $item_exists = false;
    foreach ($_SESSION['my_cart'] as $index => $item) {
        if ($item['id'] === $item_id) {
            $_SESSION['my_cart'][$index]['quantity'] += 1;
            $item_exists = true;
            break;
        }
    }
    
    // Add new item if not exists
    if (!$item_exists) {
        $_SESSION['my_cart'][] = [
            'id' => $item_id,
            'name' => sanitize_text_field($product_data['name']),
            'price' => floatval($product_data['price']),
            'image' => esc_url($product_data['image']),
            'metal' => sanitize_text_field($product_data['metal']),
            'quantity' => 1
        ];
    }
    
    // Calculate cart count and total
    $cart_count = array_sum(array_column($_SESSION['my_cart'], 'quantity'));
    $cart_total = 0;
    foreach ($_SESSION['my_cart'] as $item) {
        $cart_total += $item['price'] * $item['quantity'];
    }
    
    wp_send_json_success([
        'cart_count' => $cart_count,
        'cart_total' => $cart_total
    ]);
}

// Update cart quantity AJAX handler
add_action('wp_ajax_my_update_cart_quantity', 'my_update_cart_quantity');
add_action('wp_ajax_nopriv_my_update_cart_quantity', 'my_update_cart_quantity');

function my_update_cart_quantity() {
    my_init_cart();
    
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'my_shop_nonce')) {
        wp_send_json_error('Security check failed');
    }
    
    $item_id = sanitize_text_field($_POST['item_id']);
    $quantity = intval($_POST['quantity']);
    
    if ($quantity < 1) {
        wp_send_json_error('Quantity must be at least 1');
    }
    
    // Find and update item
    $item_found = false;
    foreach ($_SESSION['my_cart'] as $index => $item) {
        if ($item['id'] === $item_id) {
            $_SESSION['my_cart'][$index]['quantity'] = $quantity;
            $item_found = true;
            break;
        }
    }
    
    if (!$item_found) {
        wp_send_json_error('Item not found in cart');
    }
    
    // Calculate updated totals
    $cart_count = array_sum(array_column($_SESSION['my_cart'], 'quantity'));
    $cart_total = 0;
    foreach ($_SESSION['my_cart'] as $item) {
        $cart_total += $item['price'] * $item['quantity'];
    }
    
    wp_send_json_success([
        'cart_count' => $cart_count,
        'cart_total' => $cart_total
    ]);
}

// Remove from cart AJAX handler
add_action('wp_ajax_my_remove_from_cart', 'my_remove_from_cart');
add_action('wp_ajax_nopriv_my_remove_from_cart', 'my_remove_from_cart');

function my_remove_from_cart() {
    my_init_cart();
    
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'my_shop_nonce')) {
        wp_send_json_error('Security check failed');
    }
    
    $item_id = sanitize_text_field($_POST['item_id']);
    
    // Find and remove item
    foreach ($_SESSION['my_cart'] as $index => $item) {
        if ($item['id'] === $item_id) {
            array_splice($_SESSION['my_cart'], $index, 1);
            
            // Calculate updated totals
            $cart_count = array_sum(array_column($_SESSION['my_cart'], 'quantity'));
            $cart_total = 0;
            foreach ($_SESSION['my_cart'] as $item) {
                $cart_total += $item['price'] * $item['quantity'];
            }
            
            wp_send_json_success([
                'cart_count' => $cart_count,
                'cart_total' => $cart_total
            ]);
        }
    }
    
    wp_send_json_error('Item not found in cart');
}

// AJAX Clear Cart
add_action('wp_ajax_my_clear_cart', 'my_clear_cart');
add_action('wp_ajax_nopriv_my_clear_cart', 'my_clear_cart');

function my_clear_cart() {
    my_init_cart();
    $_SESSION['my_cart'] = [];
    wp_send_json_success(['message' => 'Cart cleared']);
}

// Get Cart Count
function my_get_cart_count() {
    my_init_cart();
    return array_sum(array_column($_SESSION['my_cart'] ?? [], 'quantity'));
}

// Get Cart Total
function my_get_cart_total() {
    my_init_cart();
    $total = 0;
    foreach ($_SESSION['my_cart'] ?? [] as $item) {
        $total += $item['price'] * $item['quantity'];
    }
    return $total;
}


/* ------------------------------
   A6: Enqueue Assets
------------------------------ */
function my_shop_enqueue_assets() {
    $theme = get_stylesheet_directory_uri();
    wp_enqueue_style('my-shop-css', $theme . '/assets/css/custom-shop.css', [], filemtime(get_stylesheet_directory() . '/assets/css/custom-shop.css'));
    wp_enqueue_script('my-shop-js', $theme . '/assets/js/custom-shop.js', ['jquery'], filemtime(get_stylesheet_directory() . '/assets/js/custom-shop.js'), true);

    wp_localize_script('my-shop-js', 'MY_SHOP_AJAX', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('my_shop_nonce'),
        'cart_url' => site_url('/cart'),
        'checkout_url' => site_url('/checkout')
    ]);
}
add_action('wp_enqueue_scripts', 'my_shop_enqueue_assets');


/* ------------------------------
   A7: CSV Import (Admin)
------------------------------ */
add_action('admin_menu', 'my_shop_csv_import_menu');
function my_shop_csv_import_menu() {
    add_menu_page('Import Products CSV', 'CSV Import', 'manage_options', 'my-shop-csv', 'my_shop_csv_import_page', 'dashicons-upload', 58);
}

function my_shop_csv_import_page() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="wrap"><h1>Import Products CSV</h1>';
    if (isset($_POST['my_csv_submit']) && !empty($_FILES['my_csv_file']['tmp_name'])) {
        $result = my_process_csv_import($_FILES['my_csv_file']['tmp_name']);
        if (is_array($result) && isset($result['count'])) {
            echo '<div class="updated"><p>Imported ' . intval($result['count']) . ' rows.</p></div>';
        } else {
            echo '<div class="error"><p>Import failed: ' . esc_html($result) . '</p></div>';
        }
    }
    echo '<form method="post" enctype="multipart/form-data">';
    echo '<input type="file" name="my_csv_file" accept=".csv" required />';
    submit_button('Upload & Import', 'primary', 'my_csv_submit');
    echo '</form></div>';
}

function my_process_csv_import($tmpfile) {
    $fh = fopen($tmpfile, 'r');
    if (!$fh) return 'Cannot open file.';
    $header = fgetcsv($fh);
    if (!$header) return 'No headers found.';

    $row_count = 0;
    while (($row = fgetcsv($fh)) !== FALSE) {
        $data = array_combine(array_map('sanitize_key', $header), $row);
        $title = $data['prod_name'] ?? 'Product ' . ($row_count+1);
        $content = $data['prod_long_desc'] ?? '';
        $pid = wp_insert_post(['post_title' => $title, 'post_content' => $content, 'post_status' => 'publish', 'post_type' => 'product']);
        if (is_wp_error($pid)) continue;
        foreach ($data as $k => $v) if ($v !== '') update_post_meta($pid, $k, $v);
        $row_count++;
    }
    fclose($fh);
    return ['count' => $row_count];
}

function my_shop_scroll_assets() {
    if (is_page_template('shop-page.php')) {
        wp_enqueue_style('shop-scroll-css', get_template_directory_uri() . '/assets/css/scroll-buttons.css');
        wp_enqueue_script('shop-scroll-js', get_template_directory_uri() . '/assets/js/scroll-buttons.js', [], null, true);
    }
}
add_action('wp_enqueue_scripts', 'my_shop_scroll_assets');


/* ------------------------------
   A8: Cart Page Assets (Updated)
------------------------------ */
function my_cart_checkout_assets() {
    if (is_page('cart') || is_page('checkout')) {
        // Enqueue CSS
        wp_enqueue_style(
            'my-cart-checkout-css',
            get_stylesheet_directory_uri() . '/assets/css/cart-checkout.css',
            [],
            filemtime(get_stylesheet_directory() . '/assets/css/cart-checkout.css')
        );

        // Enqueue JS
        wp_enqueue_script(
            'my-cart-checkout-js',
            get_stylesheet_directory_uri() . '/assets/js/cart-checkout.js',
            ['jquery'],
            filemtime(get_stylesheet_directory() . '/assets/js/cart-checkout.js'),
            true
        );
        
        // Localize script for AJAX - FIXED VERSION
        wp_localize_script('my-cart-checkout-js', 'MY_CART_AJAX', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('my_shop_nonce')
        ]);
    }
}
add_action('wp_enqueue_scripts', 'my_cart_checkout_assets');