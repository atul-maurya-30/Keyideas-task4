<?php
/**
 * Template Name: Product Detail Page
 */
get_header();

/* -------------------------------------------------
 *  Load CSV
 * ------------------------------------------------- */
function load_product_csv() {
    $file = get_stylesheet_directory() . '/assets/csv/products.csv';
    if (!file_exists($file)) {
        error_log('CSV file not found: ' . $file);
        return [];
    }

    // Open file for reading
    $handle = fopen($file, 'r');
    if (!$handle) {
        error_log('Failed to open CSV file: ' . $file);
        return [];
    }

    $data = [];
    $header = null;

    while (($row = fgetcsv($handle)) !== false) {
        // Skip empty lines
        if (empty(array_filter($row))) {
            continue;
        }

        if (!$header) {
            $header = array_map('trim', $row);
            continue;
        }

        // Pad row if needed
        $row = array_pad($row, count($header), '');
        $row_data = array_combine($header, $row);
        if ($row_data === false) {
            error_log('Failed to combine CSV row with header');
            continue;
        }

        // Trim all values
        $data[] = array_map('trim', $row_data);
    }

    fclose($handle);
    return $data;
}

/* -------------------------------------------------
 *  Find product
 * ------------------------------------------------- */
$products = load_product_csv();

$id_raw = isset($_GET['id']) ? sanitize_text_field(urldecode(trim($_GET['id']))) : '';
$id_raw = stripslashes($id_raw);
$product = null;

if ($id_raw !== '') {
    foreach ($products as $p) {
        $psku   = $p['prod_sku'] ?? '';
        $pname  = stripslashes($p['prod_name'] ?? '');
        $plive  = $p['prod_Live_URL'] ?? '';

        // SKU
        if ($psku && strtolower($psku) === strtolower($id_raw)) {
            $product = $p;
            break;
        }
        // Live URL
        if ($plive && strtolower($plive) === strtolower($id_raw)) {
            $product = $p;
            break;
        }
        // Name
        if ($pname && strtolower($pname) === strtolower($id_raw)) {
            $product = $p;
            break;
        }
        // Slugified name
        $slug = strtolower(preg_replace('/[^a-z0-9]+/', '-', $pname));
        if ($slug === strtolower($id_raw)) {
            $product = $p;
            break;
        }
    }

    // Numeric fallback (optional)
    if (!$product && is_numeric($id_raw) && isset($products[intval($id_raw)])) {
        $product = $products[intval($id_raw)];
    }
}

/* -------------------------------------------------
 *  No product → error
 * ------------------------------------------------- */
if (!$product) {
    echo '<div style="max-width:900px;margin:60px auto;padding:20px;font-family:Gantari,sans-serif;">';
    echo '<h2>Product not found.</h2>';
    echo '<p>Please check the product link or CSV data.</p>';
    echo '<p><strong>Debug:</strong> ID = ' . esc_html($id_raw) . '</p>';
    echo '<p><a href="' . esc_url(home_url('/shop')) . '">← Back to Shop</a></p>';
    echo '</div>';
    get_footer();
    exit;
}

/* -------------------------------------------------
 *  Gallery images
 * ------------------------------------------------- */
$image_keys = [
    'attr_whitegold_platinum_round_default_img',
    'attr_rosegold_round_default_img',
    'attr_yellowgold_round_default_img',
    'attr_whitegold_yellow_round_default_img',
    'attr_whitegold_rose_round_default_img',
    'attr_tricolor_round_default_img'
];

$gallery_images = [];
foreach ($image_keys as $k) {
    $url = $product[$k] ?? '';
    if ($url) $gallery_images[] = esc_url($url);
}

/* -------------------------------------------------
 *  Prices & metals
 * ------------------------------------------------- */
$price_14k = $product['attr_14k_regular'] ?? '';
$metal_14k = $product['attr_14k_metal_available'] ?? 'White Gold'; // Default fallback
$price_18k = $product['attr_18k_regular'] ?? '';
$metal_18k = $product['attr_18k_metal_available'] ?? 'White Gold'; // Default fallback
$price_pt  = $product['attr_platinum_regular'] ?? '';

function esc_text($str) { return esc_html($str ?? ''); }

// Ensure at least one price is available, fallback to 0 if all are empty
$default_price = $price_14k ?: ($price_18k ?: ($price_pt ?: '0'));
$default_metal = $metal_14k ?: ($metal_18k ?: ($price_pt ? 'Platinum' : 'White Gold'));
?>

<!-- -------------------------------------------------
     Back link
------------------------------------------------- -->
<nav class="custom-navbar">
    <div class="nav-container">
        <div class="nav-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="https://keyideas-wedding.iceiy.com/wp-content/uploads/2025/10/logo.6b793.png" alt="Logo">
            </a>
        </div>
        <ul class="nav-links">
            <li><a href="https://keyideas-wedding.iceiy.com/shop/">Shop</a></li>
            <li><a href="https://keyideas-wedding.iceiy.com/cart/">Cart</a></li>
            <li><a href="https://keyideas-wedding.iceiy.com/checkout/">Checkout</a></li>
        </ul>
    </div>
</nav>
<div style="max-width:1200px;margin:0 auto;padding:10px 20px;">
    <a class="pd-back-link" href="<?php echo esc_url(home_url('/shop')); ?>">← Back To Gallery</a>
</div>

<!-- -------------------------------------------------
     Main wrapper
------------------------------------------------- -->
<div class="pd-wrapper" role="main">

    <!-- Gallery -->
    <?php
    $gallery_class = (count($gallery_images) <= 1) ? 'pd-gallery pd-single' : 'pd-gallery';
    ?>
    <div class="<?php echo esc_attr($gallery_class); ?>">
        <?php if (!empty($gallery_images)): ?>
            <?php foreach ($gallery_images as $i => $url): ?>
                <div class="pd-zoom-container" data-index="<?php echo $i; ?>">
                    <img src="<?php echo $url; ?>"
                         alt="<?php echo esc_attr($product['prod_name'] ?? 'Product Image'); ?>"
                         class="pd-zoom-img" loading="lazy">
                    <div class="pd-lens"></div>
                </div>
            <?php endforeach; ?>
            <div class="pd-zoom-result"></div>
        <?php else: ?>
            <div class="pd-zoom-container">
                <img src="https://via.placeholder.com/800x800?text=No+Image"
                     alt="No Image" class="pd-zoom-img" loading="lazy">
                <div class="pd-lens"></div>
            </div>
            <div class="pd-zoom-result"></div>
        <?php endif; ?>
    </div>

    <!-- Product info -->
    <aside class="pd-info" aria-label="Product details">
        <div class="pd-title"><?php echo esc_text($product['prod_name'] ?? ''); ?></div>

        <div class="pd-price">$<span id="price-value">
            <?php echo esc_text($default_price); ?>
        </span></div>

        <!-- Metal selector -->
        <div class="pd-metal-selector" role="tablist" aria-label="Metal selector">
            <?php if ($price_14k !== ''): ?>
                <button class="pd-metal-btn <?php echo $price_14k ? 'pd-active' : ''; ?>"
                        id="btn-14k"
                        data-price="<?php echo esc_attr($price_14k); ?>"
                        data-metal="<?php echo esc_attr($metal_14k); ?>">14k</button>
            <?php endif; ?>
            <?php if ($price_18k !== ''): ?>
                <button class="pd-metal-btn <?php echo ($price_14k === '' && $price_18k) ? 'pd-active' : ''; ?>"
                        id="btn-18k"
                        data-price="<?php echo esc_attr($price_18k); ?>"
                        data-metal="<?php echo esc_attr($metal_18k); ?>">18k</button>
            <?php endif; ?>
            <?php if ($price_pt !== ''): ?>
                <button class="pd-metal-btn <?php echo ($price_14k === '' && $price_18k === '' && $price_pt) ? 'pd-active' : ''; ?>"
                        id="btn-pt"
                        data-price="<?php echo esc_attr($price_pt); ?>"
                        data-metal="Platinum">Pt</button>
            <?php endif; ?>
            <?php if (!$price_14k && !$price_18k && !$price_pt): ?>
                <p>No metal options available.</p>
            <?php endif; ?>
        </div>

        <div class="pd-available-metals">
            <strong>Available Metals:</strong>
            <span id="metal-type">
                <?php echo esc_text($default_metal); ?>
            </span>
        </div>

        <div class="pd-desc"><?php echo wpautop(esc_text($product['prod_long_desc'] ?? '')); ?></div>

        <div class="pd-attr-list">
            <p><strong>Category:</strong> <?php echo esc_text($product['prod_type'] ?? ''); ?></p>
            <p><strong>Subcategory:</strong> <?php echo esc_text($product['prod_subcategory'] ?? ''); ?></p>
            <p><strong>Section:</strong> <?php echo esc_text($product['prodmeta_section'] ?? ''); ?></p>
            <p><strong>Shipping Days:</strong> <?php echo esc_text($product['prodmeta_ship_days'] ?? ''); ?></p>
            <p><strong>Metal Weight:</strong> <?php echo esc_text($product['prodmeta_metal_weight'] ?? ''); ?></p>
            <p><strong>Side Diamonds Count:</strong> <?php echo esc_text($product['prodmeta_side_diamonds_count'] ?? ''); ?></p>
            <p><strong>Side Diamonds CTW:</strong> <?php echo esc_text($product['prodmeta_side_diamonds_ctw'] ?? ''); ?></p>
        </div>

        <div class="pd-buttons">
            <button class="pd-add-to-cart" id="add-to-cart" 
                    data-product='<?php echo json_encode([
                        "name" => $product["prod_name"] ?? "",
                        "price" => $default_price,
                        "image" => $gallery_images[0] ?? "https://via.placeholder.com/800x800?text=No+Image",
                        "metal" => $default_metal,
                        "sku" => $product["prod_sku"] ?? ""
                    ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>'>
                ADD TO CART
            </button>
            <button class="pd-wishlist" id="wishlist-btn" aria-pressed="false">❤️</button>
        </div>
        
        <!-- Cart notification -->
        <div id="cart-notification" style="display: none; background: #4CAF50; color: white; padding: 10px; margin-top: 10px; border-radius: 4px;">
            Product added to cart!
        </div>
    </aside>
</div>

<script>
(function () {
    /* -------------------------------------------------
       Metal selector
    ------------------------------------------------- */
    const btn14 = document.getElementById('btn-14k');
    const btn18 = document.getElementById('btn-18k');
    const btnPt = document.getElementById('btn-pt');
    const priceEl = document.getElementById('price-value');
    const metalEl = document.getElementById('metal-type');
    const addToCartBtn = document.getElementById('add-to-cart');

    function clearActive() {
        [btn14, btn18, btnPt].forEach(b => b && b.classList.remove('pd-active'));
    }

    function updateCartData(price, metal) {
        let productData;
        try {
            productData = JSON.parse(addToCartBtn.dataset.product);
        } catch (e) {
            console.error('Invalid JSON in data-product:', e);
            // Fallback: reconstruct basic data
            productData = {
                name: '<?php echo addslashes($product['prod_name'] ?? ''); ?>',
                price: '<?php echo $default_price; ?>',
                image: '<?php echo $gallery_images[0] ?? ''; ?>',
                metal: '<?php echo $default_metal; ?>',
                sku: '<?php echo $product['prod_sku'] ?? ''; ?>'
            };
        }
        productData.price = price || productData.price;
        productData.metal = metal || productData.metal;
        addToCartBtn.dataset.product = JSON.stringify(productData);
    }

    btn14 && btn14.addEventListener('click', () => {
        clearActive(); btn14.classList.add('pd-active');
        priceEl.textContent = btn14.dataset.price || '0';
        metalEl.textContent = btn14.dataset.metal || 'White Gold';
        updateCartData(btn14.dataset.price, btn14.dataset.metal);
    });
    btn18 && btn18.addEventListener('click', () => {
        clearActive(); btn18.classList.add('pd-active');
        priceEl.textContent = btn18.dataset.price || '0';
        metalEl.textContent = btn18.dataset.metal || 'White Gold';
        updateCartData(btn18.dataset.price, btn18.dataset.metal);
    });
    btnPt && btnPt.addEventListener('click', () => {
        clearActive(); btnPt.classList.add('pd-active');
        priceEl.textContent = btnPt.dataset.price || '0';
        metalEl.textContent = btnPt.dataset.metal || 'Platinum';
        updateCartData(btnPt.dataset.price, btnPt.dataset.metal);
    });

    /* -------------------------------------------------
       Wishlist toggle
    ------------------------------------------------- */
    const wishlistBtn = document.getElementById('wishlist-btn');
    wishlistBtn && wishlistBtn.addEventListener('click', function () {
        this.classList.toggle('pd-active');
        this.setAttribute('aria-pressed', this.classList.contains('pd-active'));
    });

    /* -------------------------------------------------
       Add to Cart
    ------------------------------------------------- */
    const cartNotification = document.getElementById('cart-notification');
    
    addToCartBtn.addEventListener('click', function() {
        let productData;
        try {
            productData = JSON.parse(this.dataset.product);
        } catch (e) {
            console.error('Failed to parse product data:', e);
            cartNotification.style.display = 'block';
            cartNotification.textContent = 'Error: Invalid product data.';
            cartNotification.style.background = '#f44336';
            setTimeout(() => cartNotification.style.display = 'none', 3000);
            return;
        }
        
        // Validate required fields before adding to cart
        if (!productData.name || !productData.price) {
            cartNotification.style.display = 'block';
            cartNotification.textContent = 'Error: Missing product details.';
            cartNotification.style.background = '#f44336';
            setTimeout(() => cartNotification.style.display = 'none', 3000);
            return;
        }

        fetch(MY_SHOP_AJAX.ajax_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: 'my_add_to_cart',
                product_data: JSON.stringify(productData),
                nonce: MY_SHOP_AJAX.nonce
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                cartNotification.style.display = 'block';
                cartNotification.textContent = 'Product added to cart!';
                cartNotification.style.background = '#4CAF50';
                
                const cartCount = document.querySelector('.cart-count');
                if (cartCount) {
                    cartCount.textContent = data.data.cart_count;
                }
                
                setTimeout(() => cartNotification.style.display = 'none', 3000);
            } else {
                cartNotification.style.display = 'block';
                cartNotification.textContent = 'Error: ' + (data.data || 'Failed to add to cart');
                cartNotification.style.background = '#f44336';
                setTimeout(() => cartNotification.style.display = 'none', 3000);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            cartNotification.style.display = 'block';
            cartNotification.textContent = 'Error adding to cart';
            cartNotification.style.background = '#f44336';
            setTimeout(() => cartNotification.style.display = 'none', 3000);
        });
    });

    /* -------------------------------------------------
       Magnifying-glass zoom (desktop only)
    ------------------------------------------------- */
    if (window.innerWidth > 768 && !('ontouchstart' in window)) {
        const containers = document.querySelectorAll('.pd-zoom-container');
        const result = document.querySelector('.pd-zoom-result');
        if (!result) return;

        result.style.display = 'none';
        result.style.position = 'absolute';
        result.style.width = '200px';
        result.style.height = '200px';
        result.style.borderRadius = '50%';
        result.style.border = '2px solid #fff';
        result.style.boxShadow = '0 0 12px rgba(0,0,0,0.25)';
        result.style.pointerEvents = 'none';
        result.style.zIndex = '100';
        result.style.backgroundSize = '250% 250%';
        result.style.backgroundRepeat = 'no-repeat';
        result.style.opacity = '0.95';

        containers.forEach(container => {
            const img = container.querySelector('.pd-zoom-img');
            const lens = container.querySelector('.pd-lens');

            if (!img || !lens) return;

            lens.style.position = 'absolute';
            lens.style.borderRadius = '50%';
            lens.style.border = '2px solid #fff';
            lens.style.backgroundColor = 'rgba(255,255,255,0.2)';
            lens.style.cursor = 'zoom-in';
            lens.style.pointerEvents = 'none';
            lens.style.display = 'none';
            lens.style.zIndex = '99';
            lens.style.boxShadow = '0 0 8px rgba(0,0,0,0.3)';
            lens.style.width = '50px';
            lens.style.height = '50px';

            container.addEventListener('mouseenter', () => {
                lens.style.display = 'block';
                result.style.display = 'block';
                result.style.backgroundImage = `url(${img.src})`;
            });

            container.addEventListener('mouseleave', () => {
                lens.style.display = 'none';
                result.style.display = 'none';
            });

            container.addEventListener('mousemove', e => {
                const rect = container.getBoundingClientRect();
                let x = e.clientX - rect.left - lens.offsetWidth / 2;
                let y = e.clientY - rect.top - lens.offsetHeight / 2;

                if (x < 0) x = 0;
                if (y < 0) y = 0;
                if (x > img.width - lens.offsetWidth) x = img.width - lens.offsetWidth;
                if (y > img.height - lens.offsetHeight) y = img.height - lens.offsetHeight;

                lens.style.left = `${x}px`;
                lens.style.top = `${y}px`;

                result.style.left = `${e.pageX + 20}px`;
                result.style.top = `${e.pageY - 100}px`;

                const bgX = (x / img.width) * 100;
                const bgY = (y / img.height) * 100;
                result.style.backgroundPosition = `${bgX}% ${bgY}%`;
            });
        });
    }
})();
</script>

<?php get_footer(); ?>