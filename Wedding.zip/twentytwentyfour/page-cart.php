<?php
/* Template Name: Cart */
get_header();

$cart = $_SESSION['cart'] ?? [];

echo "<h1>Your Cart</h1>";

if (empty($cart)) {
    echo "<p>No items in cart.</p>";
} else {
    foreach ($cart as $id) {
        $title = get_the_title($id);
        $price = get_post_meta($id, 'price', true);
        echo "<p>$title - $$price</p>";
    }
}

get_footer();
?>
