<?php
/**
 * Template Name: Cart Page
 */
get_header();

// Initialize cart from session
$cart_items = $_SESSION['my_cart'] ?? [];
$cart_total = 0;

// Calculate cart total
foreach ($cart_items as $item) {
    $cart_total += $item['price'] * $item['quantity'];
}

// Localize AJAX data for JavaScript
wp_localize_script('jquery', 'MY_CART_AJAX', [
    'ajax_url' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('my_shop_nonce')
]);
?>
<!-- ✅ Navigation Bar -->
<nav class="custom-navbar">
    <div class="nav-container">
        <div class="nav-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="https://keyideas-wedding.iceiy.com/wp-content/uploads/2025/10/logo.6b793.png" alt="Logo">
            </a>
        </div>
        <ul class="nav-links">
            <li><a href="https://keyideas-wedding.iceiy.com/shop/">Shop</a></li>
            <li><a href="https://keyideas-wedding.iceiy.com/cart/">Cart</a></li>
            <li><a href="https://keyideas-wedding.iceiy.com/checkout/">Checkout</a></li>
        </ul>
    </div>
</nav>

<div class="cart-page">
    <div class="container">
        <h1>Shopping Cart</h1>
        
        <?php if (empty($cart_items)): ?>
            <div class="empty-cart">
                <div class="empty-cart-icon">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                        <path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
                    </svg>
                </div>
                <p>Your cart is empty</p>
                <a href="<?php echo home_url('/shop'); ?>" class="continue-shopping">Continue Shopping</a>
            </div>
        <?php else: ?>
            <div class="cart-content">
                <div class="cart-items">
                    <?php foreach ($cart_items as $index => $item): ?>
                        <div class="cart-item" data-item-id="<?php echo esc_attr($item['id'] ?? $index); ?>">
                            <div class="item-image">
                                <img src="<?php echo esc_url($item['image']); ?>" alt="<?php echo esc_attr($item['name']); ?>">
                            </div>
                            <div class="item-details">
                                <h3 class="item-name"><?php echo esc_html($item['name']); ?></h3>
                                <p class="item-metal">Metal: <?php echo esc_html($item['metal']); ?></p>
                                <p class="item-price">$<?php echo number_format($item['price'], 2); ?></p>
                            </div>
                            <div class="item-quantity">
                                <label>Qty:</label>
                                <div class="quantity-controls">
                                    <button class="quantity-btn minus" data-item-id="<?php echo esc_attr($item['id'] ?? $index); ?>">-</button>
                                    <input type="number" 
                                           class="quantity-input" 
                                           value="<?php echo esc_attr($item['quantity']); ?>" 
                                           min="1" 
                                           data-item-id="<?php echo esc_attr($item['id'] ?? $index); ?>">
                                    <button class="quantity-btn plus" data-item-id="<?php echo esc_attr($item['id'] ?? $index); ?>">+</button>
                                </div>
                            </div>
                            <div class="item-total">
                                $<span class="item-total-value"><?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                            </div>
                            <div class="item-remove">
                                <button class="remove-btn" data-item-id="<?php echo esc_attr($item['id'] ?? $index); ?>">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="cart-summary">
                    <div class="summary-card">
                        <h3>Order Summary</h3>
                        <div class="summary-row">
                            <span>Subtotal:</span>
                            <span id="cart-subtotal">$<?php echo number_format($cart_total, 2); ?></span>
                        </div>
                        <div class="summary-row">
                            <span>Shipping:</span>
                            <span>Free</span>
                        </div>
                        <div class="summary-row">
                            <span>Tax:</span>
                            <span>Calculated at checkout</span>
                        </div>
                        <div class="summary-row total">
                            <span>Total:</span>
                            <span id="cart-total">$<?php echo number_format($cart_total, 2); ?></span>
                        </div>
                        <a href="<?php echo home_url('/checkout'); ?>" class="checkout-btn">Proceed to Checkout</a>
                        <a href="<?php echo home_url('/shop'); ?>" class="continue-shopping">Continue Shopping</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>